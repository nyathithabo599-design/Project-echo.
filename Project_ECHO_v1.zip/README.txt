PROJECT ECHO — VERSION 1.0

WHAT THIS IS
A mobile-friendly website and installable Progressive Web App (PWA).
The same code runs in a browser and can be installed on Android from Chrome.

FEATURES IN THIS PROTOTYPE
- Overview dashboard and navigation
- OpenStreetMap embed
- Live weather lookup using Open-Meteo (internet required)
- Links to public webcam directories (feed status must be checked with each operator)
- South African emergency call shortcut (112)
- Community observation notes saved locally on this device only
- Built-in basic help guide (not a connected AI model)
- Service worker for basic offline shell caching

IMPORTANT LIMITATIONS
- This is a prototype, not a continuously monitoring global intelligence system.
- Community reports are not uploaded or shared.
- Camera links do not guarantee a continuous live video feed.
- The built-in assistant is not generative AI.
- Weather and map content require internet.
- No private camera access, automatic emergency detection, or emergency dispatch.

HOW TO PUBLISH FREE
1. Create a GitHub account and a new public repository named project-echo.
2. Upload all files in this folder to the repository root (not inside another folder).
3. In repository Settings > Pages, select Deploy from a branch, choose main and /(root), then Save.
4. Wait for the published Pages URL. Open it in Chrome on Android.
5. In Chrome menu, choose Install app or Add to Home screen.

HOW TO INSTALL ON SAMSUNG ANDROID
1. Open the published HTTPS website in Chrome.
2. Tap the three-dot menu.
3. Choose Install app (or Add to Home screen).
4. Confirm. ECHO will appear as an app icon.

For a Play Store APK, a separate Android wrapper/build and signing process is needed. This PWA is the first installable Android version.
